package milestone.four;
import java.util.Random;
import java.util.Vector;
public class TaskService {
	private Vector<Task> taskList = new Vector<Task>();
	private int taskCount = 0;
	public Vector<Task> GetTaskList(){
		return taskList;
	}
	public int GetTaskCount() {
		return taskCount;
	}
public void AddTasks(String name, String description) {
	String newId = GenerateUniqueId();
	var newTask = new Task(newId, name, description);
	taskList.add(newTask);
	taskCount = GetTaskCount() + 1;
}
public void DeleteTasks(String name, String description) {
	if (taskCount >= 1) {
		taskList.remove(0);
		taskCount = GetTaskCount() - 1;
	}
}
public void updateTasks(String id) {
	if (taskCount >= 1) {
		if (id = newId) {
			switch(case) {
			case 1: {
				SetTaskName();
			}
			case 2:
				SetTaskDescription();
			}
		}
	}
}
public String GenerateUniqueId() {
	Random rand = new Random();
	int newId = rand.nextInt(1000000000);
	String uniqueId = Integer.toString(newId);
	return uniqueId;
}
}
