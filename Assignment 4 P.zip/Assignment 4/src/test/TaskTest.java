package test;

import static org.junit.jupiter.api.Assertions.*;
public class TaskTest {
	
	@Test
	void testTask() {
		Test test = new Test("Axl124343", "Add Background", "Add a background to the front page of the application");
		assertTrue(test.getId().equals("Ax1124343"));
		assertTrue(test.getName().equals("Add Background"));
		assertTrue(test.getDescription().equals("Add a background to the front page of the application"));
		
		
	}
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> { 
			new Task("Axl124343", "Add Background", "Add a background to the front page of the application"); 
			});  
	}
	
}
