package milestone.four;
public class Task {
//Create variables for the ID, Name, and Description
private String id;
private String name;
private String description;
//Constructor to check length of each string and if it is valid
public Task(String id, String name, String description)
{
	if (id == null || id.length() > 10) {
		throw new IllegalArgumentException("Invalid input");
	}
	if (name == null || name.length() > 20) {
		throw new IllegalArgumentException("Invalid input");
	}
	if (description == null || description.length() > 50) {
		throw new IllegalArgumentException("Invalid input");
	}
	this.id = id;
	this.name = name;
	this.description = description;
}
//Getters
public String GetId() {
	return id;
}
public String GetName() {
	return name;
}
public String GetDescription() {
	return description;
}
}
