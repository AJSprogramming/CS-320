package milestone.three;
public class Contact {
	//Create variables for the ID, First name, Last name, phone number, and address
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	//Constructor to check length of each string and if it is valid
	public Contact(String id, String firstName, String lastName, String phone, String address)
	{
		if (id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}

//Getters
public String GetId() {
	return id;
}
public String GetFirstName() {
	return firstName;
}
public String GetLastName() {
	return lastName;
}
public String GetPhone() {
	return phone;
}
public String GetAddress() {
	return address;
}
}
