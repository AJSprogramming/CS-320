package milestone.three;
import java.util.Random;
import java.util.Vector;

public class ContactService {
	private Vector<Contact> contacts = new Vector<Contact>();
	private int numContacts = 0;
	public int GetNumContacts() {
		return numContacts;
	}
	public void AddContacts(String firstName, String lastName, String phone, String address) {
		String newId = GenerateUniqueId();
		var newContact = new Contact(newId, firstName, lastName, phone, address);
		contacts.add(newContact);
		numContacts = GetNumContacts() + 1;
	}
	public void DeleteContacts(String firstName, String lastName, String phone, String address) {
		if (numContacts >= 1) {
			contacts.remove(0);
			numContacts = GetNumContacts() - 1;
		}
	}
	public String GenerateUniqueId() {
		Random rand = new Random();
		int newId = rand.nextInt(1000000000);
		String uniqueId = Integer.toString(newId);
		return uniqueId;
	}
}
