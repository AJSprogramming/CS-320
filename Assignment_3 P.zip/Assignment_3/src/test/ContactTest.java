package test;
public class ContactTest {
	@Test
	void testTask() {
		Test test = new Test("Axl124343", "AJ", "Swan", "2142525282", "123 Park Street");
		assertTrue(test.getId().equals("Ax1124343"));
		assertTrue(test.getfirstName().equals("AJ"));
		assertTrue(test.getLastName().equals("Swan"));
		assertTrue(test.getLastName().equals("2142525282"));
		assertTrue(test.getLastName().equals("123 Park Street"));
		
		
	}
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> { 
			new Task("Axl12434322", "Add Background", "Add a background to the front page of the application"); 
			});  
	}
}
