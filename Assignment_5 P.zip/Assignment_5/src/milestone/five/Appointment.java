package milestone.five;
import java.util.Date;
public class Appointment {
	private String id;
	private Date date;
	private String description;
	public Appointment(String id, Date date, String description) {
		if (id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.id = id;
		this.date = date;
		this.description = description;
	}
	public String GetId() {
		return id;
	}
	public Date GetName() {
		return date;
	}
	public String GetDescription() {
		return description;
	}
}
