package milestone.five;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

public class AppointmentService {
	private Vector<Appointment> appointmentList = new Vector<Appointment>();
	private int total = 0;
	
	public Vector<Appointment> GetAppointmentList(){
		return appointmentList;
	}
	public int GetTotal() {
		return total;
	}
	public String GenerateUniqueId() {
		Random rand = new Random();
		int newId = rand.nextInt(1000000000);
		String uniqueId = Integer.toString(newId);
		return uniqueId;
	}
	public void AddAppointment(Date date, String description) {
		String newId = GenerateUniqueId();
		var newAppointment = new Appointment(newId, date, description);
		appointmentList.add(newAppointment);
		total = GetTotal() + 1;
	}
	public void DeleteAppointment() {
		if (total >= 1) {
			appointmentList.remove(0);
			total = GetTotal() - 1;
		}
	}
}

