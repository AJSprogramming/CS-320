package test;
public class AppointmentTest {
	@Test
	void testTask() {
		Test test = new Test("Axl124343", "October 29, 2025", "Dentist Appointment at Local Dental");
		assertTrue(test.getId().equals("Ax1124343"));
		assertTrue(test.getDate().equals("October 29, 2025"));
		assertTrue(test.getDescription().equals("Dentist Appointment at Local Dental"));
		
		
	}
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> { 
			new Task("Axl124343", "October 29, 2025", "Dentist Appointment at Local Dental"); 
			});  
	}
}
